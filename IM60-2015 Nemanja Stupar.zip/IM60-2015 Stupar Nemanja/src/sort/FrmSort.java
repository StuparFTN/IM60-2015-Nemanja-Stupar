package sort;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Toolkit;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;

import java.util.Collections;

import geometry.Rectangle;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.Color;
import javax.swing.UIManager;

public class FrmSort extends JFrame {

	private JPanel contentPane;
	private JScrollPane scrlRect;
	private JList lstRectSort;
	private JScrollPane srclRectSort;
	private JList lstRect;
	private JButton btnAdd;
	private JButton btnRemove;
	private JButton btnSort;
	private DefaultListModel dlmRect;
	private DefaultListModel dlmSort;
	public int brojac;
	public int brojac2;
	private ArrayList<Rectangle> arrayRect = new ArrayList<Rectangle>();
	private JRadioButton rdbtnAscending;
	private JRadioButton rdbtnDescending;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmSort frame = new FrmSort();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmSort() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmSort.class.getResource("/resources/sort_icon.png")));

		initComponents();

		crateEvents();

	}

	private void initComponents() {

		setTitle("Stupar Nemanja IM60-2015");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 460);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(95, 158, 160));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		scrlRect = new JScrollPane();
		scrlRect.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrlRect.setBackground(new Color(255, 255, 255));

		srclRectSort = new JScrollPane();
		srclRectSort.setBackground(new Color(153, 153, 153));

		btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 15));

		btnRemove = new JButton("Remove");
		btnRemove.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JPanel panel = new JPanel();
		panel.setBackground(new Color(95, 158, 160));

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(srclRectSort, GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
								.addComponent(scrlRect, GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE))
						.addGap(18)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
												.addComponent(btnRemove, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE,
														108, GroupLayout.PREFERRED_SIZE)
												.addComponent(btnAdd, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE,
														108, GroupLayout.PREFERRED_SIZE))
										.addContainerGap())
								.addComponent(panel, Alignment.TRAILING, 0, 120, Short.MAX_VALUE))));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(46).addComponent(btnAdd)
										.addGap(18).addComponent(btnRemove).addGap(29))
								.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
										.addComponent(scrlRect, GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
										.addPreferredGap(ComponentPlacement.RELATED)))
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(srclRectSort, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(6).addComponent(panel,
										GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)))
						.addContainerGap()));

		btnSort = new JButton("Sort");
		btnSort.setFont(new Font("Tahoma", Font.PLAIN, 15));

		rdbtnAscending = new JRadioButton("Ascending");
		rdbtnAscending.setForeground(new Color(255, 255, 255));
		rdbtnAscending.setBackground(new Color(95, 158, 160));
		rdbtnAscending.setSelected(true);
		buttonGroup.add(rdbtnAscending);
		rdbtnAscending.setFont(new Font("Tahoma", Font.PLAIN, 15));

		rdbtnDescending = new JRadioButton("Descending");
		rdbtnDescending.setForeground(new Color(255, 255, 255));
		rdbtnDescending.setBackground(new Color(95, 158, 160));
		buttonGroup.add(rdbtnDescending);
		rdbtnDescending.setFont(new Font("Tahoma", Font.PLAIN, 15));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(btnSort, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
								.addComponent(rdbtnDescending).addComponent(rdbtnAscending))
						.addContainerGap(12, Short.MAX_VALUE)));
		gl_panel.setVerticalGroup(gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup().addComponent(btnSort)
						.addPreferredGap(ComponentPlacement.RELATED, 107, Short.MAX_VALUE).addComponent(rdbtnAscending)
						.addPreferredGap(ComponentPlacement.RELATED).addComponent(rdbtnDescending)));
		panel.setLayout(gl_panel);

		lstRectSort = new JList();
		lstRectSort.setFont(new Font("Tahoma", Font.PLAIN, 15));
		srclRectSort.setViewportView(lstRectSort);

		dlmSort = new DefaultListModel();
		lstRectSort.setModel(dlmSort);

		lstRect = new JList();
		lstRect.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrlRect.setViewportView(lstRect);

		dlmRect = new DefaultListModel();
		lstRect.setModel(dlmRect);

		contentPane.setLayout(gl_contentPane);

	}

	private void crateEvents() {

		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DlgSort dlgSort = new DlgSort();
				dlgSort.setVisible(true);
				if (dlgSort.isOK == true) {
					brojac++;
					dlmRect.insertElementAt("Rectangle " + brojac + ": " + dlgSort.getR().toString(), 0);

					dlgSort.getR().setN(brojac);
					arrayRect.add(0, dlgSort.getR());
				}

			}
		});

		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!(dlmRect.isEmpty())) {
					DlgSort dlgSortMod = new DlgSort();
					String[] split = dlmRect.getElementAt(0).toString().split(" ");
					dlgSortMod.getTxtXC().setText(split[6].substring(1, split[6].length() - 1));
					dlgSortMod.getTxtXC().setEnabled(false);

					dlgSortMod.getTxtYC().setText(split[7].substring(0, split[7].length() - 2));
					dlgSortMod.getTxtYC().setEnabled(false);

					dlgSortMod.getTxtHeight().setText(split[10].substring(0, split[10].length() - 1));
					dlgSortMod.getTxtHeight().setEnabled(false);

					dlgSortMod.getTxtWidth().setText(split[13]);
					dlgSortMod.getTxtWidth().setEnabled(false);

					dlgSortMod.getBtnOK().setVisible(false);
					dlgSortMod.getBtnDelete().setVisible(true);
					dlgSortMod.setVisible(true);
					if (dlgSortMod.isOK == true) {
						if (arrayRect.contains(dlgSortMod.getR1()))
							arrayRect.remove(dlgSortMod.getR1());
						dlmRect.removeElementAt(0);
						brojac--;
					}
				} else {
					getToolkit().beep();
					JOptionPane.showMessageDialog(null, "The list is empty! " + "\nAdd an object first!", "Information",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});

		btnSort.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (dlmRect.isEmpty()) {
					dlmSort.removeAllElements();
					getToolkit().beep();
					JOptionPane.showMessageDialog(null, "The list is empty! " + "\nAdd an object first!", "Information",
							JOptionPane.INFORMATION_MESSAGE);
				}

				if (rdbtnAscending.isSelected()) {
					dlmSort.removeAllElements();
					Collections.sort(arrayRect);
				} else {
					dlmSort.removeAllElements();
					Collections.reverse(arrayRect);
				}

				brojac2 = 0;

				for (Rectangle r : arrayRect) {
					brojac2++;
					dlmSort.addElement(brojac2 + ". " + "Rectangle " + r.getN() + ": " + r.area());
				}

			}
		});

	}
}
