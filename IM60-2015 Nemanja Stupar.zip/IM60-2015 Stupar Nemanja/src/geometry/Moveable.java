package geometry;

public interface Moveable {

	public abstract void moveBy(int byX, int byY);

}
